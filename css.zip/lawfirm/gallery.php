<?php
	$page_title = 'Gallery';
	$current_page_link ='gallery';
	include ('includes/header.html');
?>

           <section>
                <h1 class="page-header">Gallery</h1>
            </section>

  <div class="container">
        <div class="row">

            <div class="col-sm-4 portfolio-item">
                <a href="portfolio-item.html">
                    <img class="img-responsive" src="http://placehold.it/750x450">
                </a>
            </div>

            <div class="col-sm-4 portfolio-item">
                <a href="portfolio-item.html">
                    <img class="img-responsive" src="http://placehold.it/750x450">
                </a>
            </div>

            <div class="col-sm-4 portfolio-item">
                <a href="portfolio-item.html">
                    <img class="img-responsive" src="http://placehold.it/750x450">
                </a>
            </div>

        </div>
        
                <div class="row">

            <div class="col-sm-4 portfolio-item">
                <a href="portfolio-item.html">
                    <img class="img-responsive" src="http://placehold.it/750x450">
                </a>
            </div>

            <div class="col-sm-4 portfolio-item">
                <a href="portfolio-item.html">
                    <img class="img-responsive" src="http://placehold.it/750x450">
                </a>
            </div>

            <div class="col-sm-4 portfolio-item">
                <a href="portfolio-item.html">
                    <img class="img-responsive" src="http://placehold.it/750x450">
                </a>
            </div>

        </div>
        
                <div class="row">

            <div class="col-sm-4 portfolio-item">
                <a href="portfolio-item.html">
                    <img class="img-responsive" src="http://placehold.it/750x450">
                </a>
            </div>

            <div class="col-sm-4 portfolio-item">
                <a href="portfolio-item.html">
                    <img class="img-responsive" src="http://placehold.it/750x450">
                </a>
            </div>

            <div class="col-sm-4 portfolio-item">
                <a href="portfolio-item.html">
                    <img class="img-responsive" src="http://placehold.it/750x450">
                </a>
            </div>

        </div>

   </div>
   
   <script type="text/javascript">
       $("#gallery").addClass("active");
   </script>
   
	<?php
	include ('includes/footer.html');
	?>